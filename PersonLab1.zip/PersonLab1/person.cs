﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonLab1
{
    internal class person
    {
        private int id;
        private string firstName;
        private string lastName;
        private int age;
        private string favouriteColor;
        private bool isWorking;

        public int Id { get => id; set => id = value; }
        public string FirstName { get => firstName; set => firstName = value; }
        public string LastName { get => lastName; set => lastName = value; }
        public int Age { get => age; set => age = value; }
        public string FavouriteColor { get => favouriteColor; set => favouriteColor = value; }
        public bool IsWorking { get => isWorking; set => isWorking = value; }

        public person(int id, string firstName, string lastname, int age, string favouriteColor, bool isWorking)
        {
            this.id = id;
            this.firstName = firstName;
            this.LastName = lastName;
            Age = age;
            FavouriteColor = favouriteColor;
            IsWorking = isWorking;

        }

        public string DisplayPersonInfo()
        {
            return (firstName + "" + lastName + "" + "'s Favourite color is :" + favouriteColor);
        }
        


        public int GetAgeInTenYears()
        {
            return Age + 10;
        }

        public void ChangeFavoriteColour()
        {
            FavouriteColor = "white";
        }

        public override string ToString()
        {
            string formatted = "";

            formatted += "ID: " + id + "\n";
            formatted += "First name: " + firstName + "\n";
            formatted += "Last name: " + lastName + "\n";
            formatted += "favourite color:" + favouriteColor + "\n";
            formatted += "age:" + age + "\n";
            formatted += "isWorking:" + isWorking + "\n";




            return formatted;

        }

       

    } 






    

}
