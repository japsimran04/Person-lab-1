﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonLab1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            person person1 = new person(1, "Ian", "Brooks", 30, "Red", true);
            person person2 = new person(2, "Gina", "james", 20, "Red", false);
            person person3 = new person(3, "Mike", "Briscoe", 45, "Blue", true);
            person person4 = new person(4, "Mary", "Beals", 28, "Yellow", true);



            person1.ChangeFavoriteColour();
            Console.WriteLine(person1.DisplayPersonInfo());

            int newage = person4.GetAgeInTenYears();
            Console.WriteLine(person4.FirstName + "" + person4.LastName + "'s age after 10 years :" + newage);





            Console.WriteLine(person2.ToString());
            Console.ReadLine();
            Console.WriteLine(person3.ToString());
            Console.ReadLine();
            Console.WriteLine(person4.ToString());
            Console.ReadLine();
            Console.WriteLine(person1.ToString());
            Console.ReadLine();


            

           
            List<person> people = new List<person>();

            people.Add(person1);
            people.Add(person2);
            people.Add(person3);
            people.Add(person4);


            int sum = 0;

            foreach (person person in people)
            {
                sum += person.Age;


            }

            double average = sum / (double) people.Count;

            Console.WriteLine("Average age is " +  (average) );


        }


        
    }
}
